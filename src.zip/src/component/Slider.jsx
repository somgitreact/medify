import React from 'react'

const Slider = () => {
  return (
    <div className='wrap pt-[100px] pb-[60px]'>Slider</div>
  )
}

export default Slider